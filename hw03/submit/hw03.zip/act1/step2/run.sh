#!/bin/bash
for i in {1..1}; do
    echo "Trial $i"
    python act1step2.py
    echo "Done $i"
done