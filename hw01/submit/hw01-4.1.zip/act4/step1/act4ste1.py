import requests


def main():
    r = requests.get('http://csec.rit.edu')


if __name__ == '__main__':
    main()
